<?php
function FunctionName($jumlah = 0, $judul = null, $gambar = null )
{
    echo '
    <div class="col 12">
      <div class="card  text-light purp-bg">
        <div class="row g-0">
        <div class="col-md-8 ">
            <div class="card-body ">
              <h5 class="card-title">',$jumlah,'</h5>
              <p class="card-text">',$judul,'</p>

            </div>
          </div>
      <div class="col-md-4 position-relative">
        <i class="',$gambar,' img-fluid position-absolute top-100 start-50 translate-middle icon-size"></i>
      </div>
    </div>
      </div>
    </div>';
}
?>

<?php if(auth()->guard()->guest()): ?>

<?php else: ?>
<?php $__env->startSection('body'); ?>
<div class="container row">
  <div class="col-12">
    <form action="/" method="GET" class="col-12 " >
      <div class="row pt-5 pb-5 radius align-items-end">
  
        <div class="col d-inline">
            <div class="btn-group">
              <select class="form-select" aria-label="Default select example" name="rt">
                <option selected value="">PILIH RT</option>
                <?php $__currentLoopData = $rts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($rt->id); ?>"><?php echo e($rt->id); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

          <div class="col d-inline">
            <div class="btn-group">
              <select class="form-select" aria-label="Default select example" name="rw">
                <option selected value=""">PILIH RW</option>
                <?php $__currentLoopData = $rws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($rw->id); ?>"><?php echo e($rw->id); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
          <div class="col d-inline">
            <div class="btn-group">
              <select class="form-select" aria-label="Default select example" name="dusun">
                <option selected value="">PILIH DUSUN</option>
                <?php $__currentLoopData = $dusuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dusun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($dusun->id); ?>"><?php echo e($dusun->deskripsi); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
          <div class="col d-inline">
              <button type="submit" class="btn btn-primary">
                Tampilkan
              </button>
          </div>
        </div>
      </form>
  </div>
  </div>
</div>
  <div class="row row-cols-1 row-cols-md-3 g-4 mx-xxl-3 bg-white py-3 radius">
    <?php FunctionName($penduduk,  "Penduduk" ,"fa-solid fa-user-group" ); ?>
    <?php FunctionName($kepala_keluarga, 'Kepala Keluarga',"fa-solid fa-id-card"); ?>
    <?php FunctionName($laki, 'Laki-laki',"fa-solid fa-mars"); ?>
    <?php FunctionName($perempuan, 'Perempuan',"fa-solid fa-venus"); ?>
    <?php FunctionName($lahir, 'Lahir',"fa-solid fa-face-smile"); ?>
    <?php FunctionName($meninggal, 'Meninggal',"fa-solid fa-face-frown"); ?>
    <div class="col-xl-12">
      <div class="card mb-4 ">
        <div class="card-header">
          <i class="fas fa-chart-area me-1"></i>
          PENDIDIKAN
        </div>
        <div class="card-body"><canvas id="myChart" width="100%" height="40"></canvas></div>
      </div>
    </div>
  </div>
  <br>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    const labels = [
      'Tamat SD',
      'SLTP',
      'SLTA',
      'DIPLOMA I/II',
      'AKADEMI/D III',
      'DIPLOMA IV/STRATA I/STRATA II',
      'STRATA III',
      'LAINNYA'
    ];

    const data = {
      labels: labels,
      datasets: [{
        label: 'Jumlah warga Pendidikan',
        backgroundColor: 'rgb(120,97,148)',
        borderColor: 'rgb(120,97,148)',
        color: 'rgb(240, 242, 250)',
        data: [<?php echo e($tamatsd); ?>, <?php echo e($sltp); ?>, <?php echo e($slta); ?>, <?php echo e($d12); ?>, <?php echo e($d3); ?>, <?php echo e($s1); ?>, <?php echo e($s2); ?>, <?php echo e($s3); ?>],
      }]
    };

    const config = {
      type: 'bar',
      data: data,
      options: {}
    };
  </script>
  <script>
    const myChart = new Chart(
      document.getElementById('myChart'),
      config
    );
  </script>
    <script>
          const config = {
            type: 'bar',
            data: data,
            options: {}
          };
        </script>
        <script>
          const myChart = new Chart(
            document.getElementById('myChart'),
            config
          );
        </script>
    <?php $__env->stopSection(); ?>
    <?php endif; ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\My Computer\Documents\CODE\Web\Sistem Kependudukan\web-kependudukan\resources\views/dashboard.blade.php ENDPATH**/ ?>