

<?php $__env->startSection('body'); ?>
    <div class="container ">
        <div class="content bg-white p-1">
            <form action="/data_penduduk/edit/<?php echo e($penduduk->id); ?>" method="POST">

                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12 background text-black text-center p-1" style="">Edit data penduduk </div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label class="form-label" for="nik">NIK</label></div>
                    <div class="col-8"><input class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nik"
                            style="width: 50%" type="text" placeholder="NIK" name="nik" value="<?php echo e($penduduk->nik); ?>">
                    </div>
                    <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-4"></div>
                        <div class="col-4">
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row my-3">
                    <div class="col-4 "><label class="form-label " for="kk">No KK</label></div>
                    <div class="col-8 "><input class="form-control <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kk"
                            style="width: 50%" type="text" placeholder="Nomer KK" name="kk"
                            value="<?php echo e($penduduk->kk); ?>"></div>
                    <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-4"></div>
                        <div class="col-4">
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row my-3">
                    <div class="col-4 "><label class="form-label " for="validasi">Validasi</label></div>
                    <div class="col-8 "><input class="form-control <?php $__errorArgs = ['validasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="validasi"
                            style="width: 50%" type="text" placeholder="Validasi KK" name="validasi"
                            value="<?php echo e($penduduk->validasi); ?>"></div>
                    <?php $__errorArgs = ['validasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-4"></div>
                        <div class="col-4">
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row my-3">
                    <div class="col-4 "><label class="form-label " for="nama">Nama</label></div>
                    <div class="col-8 "><input class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama"
                            style="width: 50%" type="text" placeholder="Nama" name="nama"
                            value="<?php echo e($penduduk->nama); ?>"></div>
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-4"></div>
                        <div class="col-4">
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row my-3">
                    <div class="col-4 form-label">TTL</div>
                    <div class="col-8">
                        <input style="width: 25%" type="text"
                            class="form-control <?php $__errorArgs = ['ttl-tempat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Tempat lahir"
                            name="ttl-tempat" value="<?php echo e($penduduk->tempat_lahir); ?>">
                        <input style="width: 25%" type="date"
                            class="form-control <?php $__errorArgs = ['ttl-waktu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Tanggal lahir"
                            name="ttl-waktu" value="<?php echo e($penduduk->tanggal_lahir); ?>">
                        <?php $__errorArgs = ['ttl-tempat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">
                                <span class="text-danger">Tempat belum diisi! </span>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['ttl-waktu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">
                                <span class="text-danger">Tanggal belum diisi! </span>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                </div>


                <div class="row my-3">
                    <div class="col-4 ">Jenis Kelamin</div>
                    <div class="col-8 ">
                        <select style="width: 25%" id="inputGroupSelect01" required name="kelamin"
                            class="form-select <?php $__errorArgs = ['kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled value="">PILIH KELAMIN</option>

                            <option value="L" <?php echo e($penduduk->kelamin == 'L' ? 'selected' : ''); ?>>Laki-Laki</option>
                            <option value="P" <?php echo e($penduduk->kelamin == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                        </select>
                    </div>
                </div>

                <div class="row my-3">
                    <div class="col-4 "><label class="form-label" for="nama_ayah">Nama Ayah</label></div>
                    <div class="col-8"><input class="form-control <?php $__errorArgs = ['nama_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="nama_ayah" style="width: 50%" type="text" placeholder="Nama Ayah" name="nama_ayah"
                            value="<?php echo e($penduduk->nama_ayah); ?>"></div>
                    <?php $__errorArgs = ['nama_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-4"></div>
                        <div class="col-4">
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row my-3">
                    <div class="col-4 "><label class="form-label" for="nama_ibu">Nama Ibu</label></div>
                    <div class="col-8"><input class="form-control <?php $__errorArgs = ['nama_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="nama_ibu" style="width: 50%" type="text" placeholder="Nama Ibu" name="nama_ibu"
                            value="<?php echo e($penduduk->nama_ibu); ?>"></div>
                    <?php $__errorArgs = ['nama_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-4"></div>
                        <div class="col-4">
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row my-3">
                    <div class="col-4 ">RT</div>
                    <div class="col-8 ">

                        <select style="width: 25%" id="inputGroupSelect01" name="rt"
                            class="form-select <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option selected disabled value="">PILIH RT</option>
                            <?php $__currentLoopData = $rt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"
                                    <?php echo e($penduduk->rt->id == $item->id ? 'selected' : ''); ?>><?php echo e($item->id); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-4 ">Agama</div>
                    <div class="col-8 ">

                        <select style="width: 25%" id="inputGroupSelect01" name="agama" required
                            class="form-select <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled value="">PILIH AGAMA</option>
                            <?php $__currentLoopData = $agama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->deskripsi); ?>"
                                    <?php echo e($penduduk->agama == $item->deskripsi ? 'selected' : ''); ?>><?php echo e($item->deskripsi); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="row my-3">
                    <div class="col-4 ">Pendidikan</div>
                    <div class="col-8 ">

                        <select style="width: 25%" id="inputGroupSelect01" name="pendidikan" required
                            class="form-select">
                            <option selected disabled value="">PILIH PENDIDIKAN</option>
                            <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->deskripsi); ?>"
                                    <?php echo e($penduduk->pendidikan == $item->deskripsi ? 'selected' : ''); ?>>
                                    <?php echo e($item->deskripsi); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="row my-3">
                    <div class="col-4 ">Pekerjaan</div>
                    <div class="col-8 ">

                        <select style="width: 25%" id="inputGroupSelect01" name="pekerjaan" required
                            class="form-select">
                            <option selected disabled value="">PILIH PEKERJAAN</option>
                            <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->deskripsi); ?>"
                                    <?php echo e($penduduk->pekerjaan == $item->deskripsi ? 'selected' : ''); ?>>
                                    <?php echo e($item->deskripsi); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>


                <div class="row my-3">
                    <div class="col-4 ">Hubungan Keluarga</div>
                    <div class="col-8 ">
                        <select style="width: 25%" id="inputGroupSelect01" name="hubungan_keluarga" required
                            class="form-select">
                            <option selected disabled value="">PILIH HUB-KELUARGA</option>
                            <?php $__currentLoopData = $hubungan_keluarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->deskripsi); ?>"
                                    <?php echo e($penduduk->hubungan_keluarga == $item->deskripsi ? 'selected' : ''); ?>>
                                    <?php echo e($item->deskripsi); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>


                <div class="row my-3">
                    <div class="col-4 "><label for="status-perkawinan">Status Perkawinan</label></div>
                    <div class="col-8 ">
                        <select style="width: 25%" id="inputGroupSelect01" name="status_perkawinan"
                            id="status-perkawinan" required class="form-select">
                            <option selected disabled value="">PILIH STATUS</option>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->deskripsi); ?>"
                                    <?php echo e($penduduk->status_perkawinan == $item->deskripsi ? 'selected' : ''); ?>>
                                    <?php echo e($item->deskripsi); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                        </select>
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label for="exampleRadios1">Status Penduduk Baru</label></div>
                    <div class="col-8 ">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status_penduduk_baru"
                                id="exampleRadios1" value="Baru" required
                                <?php echo e($penduduk->status_penduduk_baru == 'Baru' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="exampleRadios1">
                                Baru
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status_penduduk_baru"
                                id="exampleRadios2" value="Pindah Masuk"
                                <?php echo e($penduduk->status_penduduk_baru == 'Pindah' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="exampleRadios2">
                                Pindah Masuk
                            </label>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 background text-black text-center " style="">NIK Orangtua</div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label class="form-label " for="kemiskinan">Nik Ibu</label></div>
                    <div class="col-8 "><input class="form-control" id="kemiskinan" style="width: 50%" type="text" placeholder="NIK IBU" name="nik_ibu"  value="<?php echo e($penduduk->nik_ibu); ?>"></div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label class="form-label " for="kemiskinan">Nik Ayah</label></div>
                    <div class="col-8 "><input class="form-control" id="kemiskinan" style="width: 50%" type="text" placeholder="NIK AYAH" name="nik_ayah"  value="<?php echo e($penduduk->nik_ayah); ?>"></div>
                </div>


                <div class="row">
                    <div class="col-12 background text-black text-center " style="">Kelahiran</div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label class="form-label" for="akte_kelahiran">Akte Kelahiran</label></div>
                    <div class="col-8 "><input class="form-control" style="width: 50%" type="text"
                            placeholder="Akte Kelahiran"name="akte_kelahiran" id="akte_kelahiran"
                            value="<?php echo e($penduduk->akte_kelahiran); ?>"></div>
                </div>
                <div class="row">
                    <div class="col-12 background text-black text-center " style="">Pernikahan</div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label for="tanggal_nikah" class="form-label">Tanggal nikah</label></div>
                    <div class="col-8 ">
                        <input style="width: 50%" type="date" name="tanggal_nikah" class="form-control"
                            id="tanggal_nikah" value="<?php echo e($penduduk->tanggal_nikah); ?>">
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label for="no_buku_nikah" class="form-label">No buku nikah</label></div>
                    <div class="col-8 ">
                        <input style="width: 50%" type="text" name="no_buku_nikah" class="form-control"
                            value="<?php echo e($penduduk->nomor_buku_nikah); ?>">
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label for="kua" class="form-label">KUA</label></div>
                    <div class="col-8 ">
                        <input style="width: 50%" type="text" name="kua" class="form-control"
                            value="<?php echo e($penduduk->kua); ?>">
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 background text-black text-center " style="">Perceraian</div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label for="tanggal_nikah" class="form-label">Tanggal cerai</label></div>
                    <div class="col-8 ">
                        <input style="width: 50%" type="date" name="tanggal_cerai" class="form-control" id="tanggal_cerai" value="<?php echo e($penduduk->tanggal_cerai); ?>">
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label for="no_akta_cerai" class="form-label">No akta perceraian</label></div>
                    <div class="col-8 ">
                        <input style="width: 50%" type="text" name="no_akta_cerai" id="no_akta_cerai" class="form-control" value="<?php echo e($penduduk->nomor_akta_cerai); ?>">
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 background text-black text-center " style="">Kematian</div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label for="tanggal_kematian" class="form-label">Tanggal Kematian</label></div>
                    <div class="col-8 ">
                        <input style="width: 50%" type="date" id="tanggal_kematian" name="tanggal_kematian"
                            value="<?php echo e($penduduk->tanggal_kematian); ?>" class="form-control">
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label for="waktu_kematian" class="form-label">Waktu Kematian</label></div>
                    <div class="col-8 ">
                        <input style="width: 50%" type="time" id="waktu_kematian" name="waktu_kematian"
                            value="<?php echo e($penduduk->waktu_kematian); ?>" class="form-control">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 background text-black text-center " style="">Kemiskinan</div>
                </div>
                <div class="row my-3">
                    <div class="col-4 "><label class="form-label " for="kemiskinan">Keterangan</label></div>
                    <div class="col-8 "><input class="form-control" id="kemiskinan" style="width: 50%" type="text"
                            placeholder="Keterangan kemiskinan" name="kemiskinan" value="<?php echo e($penduduk->kemiskinan); ?>">
                    </div>
                </div>

        </div>
        <br>
        <button  class="btn btn-success"><svg xmlns="http://www.w3.org/2000/svg" width="16"
                height="16" fill="currentColor" class="bi bi-sd-card-fill" viewBox="0 0 16 16">
                <path
                    d="M12.5 0H5.914a1.5 1.5 0 0 0-1.06.44L2.439 2.853A1.5 1.5 0 0 0 2 3.914V14.5A1.5 1.5 0 0 0 3.5 16h9a1.5 1.5 0 0 0 1.5-1.5v-13A1.5 1.5 0 0 0 12.5 0Zm-7 2.75a.75.75 0 0 1 .75.75v2a.75.75 0 0 1-1.5 0v-2a.75.75 0 0 1 .75-.75Zm2 0a.75.75 0 0 1 .75.75v2a.75.75 0 0 1-1.5 0v-2a.75.75 0 0 1 .75-.75Zm2.75.75v2a.75.75 0 0 1-1.5 0v-2a.75.75 0 0 1 1.5 0Zm1.25-.75a.75.75 0 0 1 .75.75v2a.75.75 0 0 1-1.5 0v-2a.75.75 0 0 1 .75-.75Z" />
            </svg> Simpan</button>

        <a href="/data_penduduk"><button class="mx-3 btn btn-secondary"><svg xmlns="http://www.w3.org/2000/svg"
                    width="16" height="16" fill="currentColor" class="bi bi-arrow-90deg-left"
                    viewBox="0 0 16 16">
                    <path fill-rule="evenodd"
                        d="M1.146 4.854a.5.5 0 0 1 0-.708l4-4a.5.5 0 1 1 .708.708L2.707 4H12.5A2.5 2.5 0 0 1 15 6.5v8a.5.5 0 0 1-1 0v-8A1.5 1.5 0 0 0 12.5 5H2.707l3.147 3.146a.5.5 0 1 1-.708.708l-4-4z" />
                </svg> Batal</button></a>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\My Computer\Documents\CODE\Web\Sistem Kependudukan\web-kependudukan\resources\views/edit_penduduk.blade.php ENDPATH**/ ?>