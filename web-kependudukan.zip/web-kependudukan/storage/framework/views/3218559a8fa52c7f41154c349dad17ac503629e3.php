<head>
    <style>
        th, td {
  border: 1px solid black;
  border-collapse: collapse;
  vertical-align: middle;
  padding: 5px

}
th{
    font-weight: bold
}
    </style>
</head>
<table>
    <thead>
        <tr>
            <th><strong>DATA PENDUDUK</strong></th>
        </tr>
        <tr>
            <th><strong>DESA SUMBEREJO KECAMATAN GEDANGAN</strong></th>
        </tr>
        <tr>

        </tr>
        <tr>
            <th rowspan="2" style="text-align: center;"></th>
            <th rowspan="2" style="text-align: center;">NOMOR KK</th>
            <th rowspan="2" style="text-align: center;">VALIDASI</th>
            <th rowspan="2" style="text-align: center;">NIK</th>
            <th rowspan="2" style="text-align: center;">NAMA</th>
            <th rowspan="2" style="text-align: center;">TEMPAT LAHIR</th>
            <th rowspan="2" style="text-align: center;">TANGGAL LAHIR</th>
            <th rowspan="2" style="text-align: center;">UMUR</th>
            <th rowspan="2" style="text-align: center;">HUBUNGAN KELUARGA</th>
            <th rowspan="2" style="text-align: center;">STATUS</th>
            <th rowspan="2" style="text-align: center;">PENDIDIKAN</th>
            <th rowspan="2" style="text-align: center;">L/P</th>
            <th rowspan="2" style="text-align: center;">AGAMA</th>
            <th rowspan="2" style="text-align: center;">PEKERJAAN</th>
            <th colspan="2" style="text-align: center;">NAMA ORANGTUA</th>
            <th rowspan="2" style="text-align: center; background: yellow; color: red">MISKIN</th>
            <th colspan="3" style="text-align: center;">ALAMAT</th>
            <th rowspan="2" style="text-align: center;">TANGGAL NIKAH</th>
            <th rowspan="2" style="text-align: center;">NOMOR BUKU NIKAH</th>
            <th rowspan="2" style="text-align: center;">KUA</th>
            <th rowspan="2" style="text-align: center;">AKTE KELAHIRAN/SURAT KENAL LAHIR</th>
            <th colspan="3" style="text-align: center;">KEMATIAN</th>
            <th rowspan="2" style="text-align: center;">NOMOR PBI JK/BPJS</th>
            <th rowspan="2" style="text-align: center;">JABATAN</th>
            <th rowspan="2" style="text-align: center;">TELEPON</th>
            <th rowspan="2" style="text-align: center;">NOMOR IJAZAH/STTB</th>
            <th colspan="2" style="text-align: center;">NIK ORANGTUA</th>
            <th colspan="2" style="text-align: center;">PERCERAIAN</th>
            <th rowspan="2" style="text-align: center;">GOLONGAN DARAH</th>
            <th rowspan="2" style="text-align: center;">PENYANDANG CACAT</th>
            <th rowspan="2" style="text-align: center;">KEWARGANEGARAAN</th>
            <th rowspan="2" style="text-align: center;">STATUS PENDUDUK BARU</th>
        </tr>
        <tr>
            <td style="text-align: center;">IBU</td>
            <td style="text-align: center;">AYAH</td>
            <td style="text-align: center;">RT</td>
            <td style="text-align: center;">RW</td>
            <td style="text-align: center;">DUSUN</td>
            <td style="text-align: center;">TANGGAL KEMATIAN</td>
            <td style="text-align: center;">PUKUL</td>
            <td style="text-align: center;">KETERANGAN</td>
            <td style="text-align: center;">NIK IBU</td>
            <td style="text-align: center;">NIK AYAH</td>
            <td style="text-align: center;">TANGGAL CERAI</td>
            <td style="text-align: center;">NOMOR AKTA CERAI</td>
        </tr>
        <tr>
            <?php for ($i=1; $i <=40; $i++) {?>
                    <td style="text-align: center;"><?=$i?></td>                
            <?php } ?>
        </tr>
        <tr>

        </tr>
    </thead>
    <tbody>
        <?php $index=0?>
        <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index++); ?></td>
                <td><?php echo e($penduduk->kk); ?></td>
                <td><?php echo e($penduduk->validasi); ?></td>
                <td><?php echo e($penduduk->nik); ?></td>
                <td><?php echo e($penduduk->nama); ?></td>
                <td><?php echo e($penduduk->tempat_lahir); ?></td>
                <td><?php echo e(($penduduk->tanggal_lahir =="" ? "": "=DATEVALUE(\"{$penduduk->tanggal_lahir}\")")); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($penduduk->tanggal_lahir)->age); ?></td>
                <td><?php echo e($penduduk->hubungan_keluarga); ?></td>
                <td><?php echo e($penduduk->status_perkawinan); ?></td>
                <td><?php echo e($penduduk->pendidikan); ?></td>
                <td><?php echo e($penduduk->kelamin); ?></td>
                <td><?php echo e($penduduk->agama); ?></td>
                <td><?php echo e($penduduk->pekerjaan); ?></td>
                <td><?php echo e($penduduk->nama_ibu); ?></td>
                <td><?php echo e($penduduk->nama_ayah); ?></td>
                <td><?php echo e($penduduk->kemiskinan); ?></td>
                <td><?php echo e($penduduk->rt_id); ?></td>
                <td><?php echo e(($penduduk->rt_id=="" ? $penduduk->rt_id :  $penduduk->rt->rw->id )); ?></td>
                <td><?php echo e(($penduduk->rt_id==""? $penduduk->rt_id:$penduduk->rt->rw->dusun->deskripsi )); ?></td>
                <td><?php echo e(($penduduk->tanggal_nikah =="" ? "": "=DATEVALUE(\"{$penduduk->tanggal_nikah}\")")); ?></td>
                <td><?php echo e($penduduk->nomor_buku_nikah); ?></td>
                <td><?php echo e($penduduk->kua); ?></td>
                <td><?php echo e($penduduk->akte_kelahiran); ?></td>
                <td><?php echo e(($penduduk->tanggal_kematian =="" ? "": "=DATEVALUE(\"{$penduduk->tanggal_kematian}\")")); ?></td>
                <td><?php echo e($penduduk->waktu_kematian); ?></td>
                <td><?php echo e($penduduk->keterangan_kematian); ?></td>
                <td><?php echo e($penduduk->nomor_bpjs); ?></td>
                <td><?php echo e($penduduk->jabatan); ?></td>
                <td><?php echo e($penduduk->telepon); ?></td>
                <td><?php echo e($penduduk->nomor_ijazah); ?></td>
                <td><?php echo e($penduduk->nik_ibu); ?></td>
                <td><?php echo e($penduduk->nik_ayah); ?></td>
                <td><?php echo e(($penduduk->tanggal_cerai =="" ? "": "=DATEVALUE(\"{$penduduk->tanggal_cerai}\")")); ?></td>
                <td><?php echo e($penduduk->nomor_akta_cerai); ?></td>
                <td><?php echo e($penduduk->golongan_darah); ?></td>
                <td><?php echo e($penduduk->penyandang_cacat); ?></td>
                <td>WNI</td>
                <td><?php echo e($penduduk->status_penduduk_baru); ?></td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\My Computer\Documents\CODE\Web\Sistem Kependudukan\web-kependudukan\resources\views/export/penduduk.blade.php ENDPATH**/ ?>