
<?php $__env->startSection('body'); ?>
<main>
    <div class="container-fluid px-4">
        <div class="card mb-4">
            <div class="card-header">
                <a href="/tambah"><button type="button" class="btn btn-primary"><img src="/assets/logoTambah.png"> tambah</button></a>
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>Alamat</th>
                            <th>No KK</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>Alamat</th>
                            <th>No KK</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        
                        <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($penduduk->id); ?></td>
                            <td><?php echo e($penduduk->nik); ?></td>
                            <td><?php echo e($penduduk->nama); ?></td>
                            <td><?php echo e($penduduk->kelamin==1 ? "L" : 'P'); ?></td>
                            <td>RT <?php echo e($penduduk->rt->id); ?>/RW <?php echo e($penduduk->rt->rw->id); ?>/DUSUN <?php echo e($penduduk->rt->rw->dusun->deskripsi); ?></td>
                            <td><?php echo e($penduduk->kk); ?></td>
                            <td><a href="/detail"><img src="/assets/logoInfo.png"></a>
                                <a href="#"><img src="/assets/logoEdit.png"></a>
                                <a href="#"><img src="/assets/logoDelete.png"></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\My Computer\Documents\CODE\Web\Sistem Kependudukan\web-kependudukan\resources\views/perpindahan.blade.php ENDPATH**/ ?>